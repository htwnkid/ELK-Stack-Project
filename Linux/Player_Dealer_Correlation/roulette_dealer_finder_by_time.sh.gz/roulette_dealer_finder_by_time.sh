
#!/bin/bash

clear

#PS3="Select a file to process: "

filename_ext="_Dealer_schedule"

printf "Please enter the first four digits of the Dealer File to be processed (EX. 0310)\n\n"

read FILE_DATE

printf "\n\nPlease enter the Time desired (Ex. 05:00:00 AM, Please enter either AM or PM)\n\n"

read FILE_TIME

case $FILE_DATE in

       0310 )
         
	     case "$FILE_TIME" in

		"05:00:00 AM" ) 

                                printf "\nThe Suspected Dealer is: " ;
				awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '05:00:00 AM' ;
                                printf "\n" ;;

		"08:00:00 AM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '08:00:00 AM' ;
                                printf "\n" ;;

		"02:00:00 PM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '02:00:00 PM' ;
                                printf "\n" ;;

		"08:00:00 PM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '08:00:00 PM' ;
                                printf "\n" ;;

		"11:00:00 PM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '11:00:00 PM' ;
                                printf "\n" ;; 
				

             esac  ;;

	0312 )

             case $FILE_TIME in

                "05:00:00 AM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '05:00:00 AM' ;
                                printf "\n" ;; 

                "08:00:00 AM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '08:00:00 AM' ;
                                printf "\n" ;;

                "02:00:00 PM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '02:00:00 PM' ;
                                printf "\n" ;; 

                "08:00:00 PM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '08:00:00 PM' ;
                                printf "\n" ;;

                "11:00:00 PM") 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '11:00:00 PM' ;
                                printf "\n" ;; 

             esac ;;

	0315 )

             case $FILE_TIME in

                "05:00:00 AM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '05:00:00 AM' ;
                                printf "\n" ;; 

                "08:00:00 AM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '08:00:00 AM' ;
                                printf "\n" ;; 

                "02:00:00 PM" ) 

                                printf "\nThe Suspected Dealer is: " ;
                                awk -F'\t' '{print $1, $3}' $FILE_DATE$filename_ext | grep -e '02:00:00 PM' ;
                                printf "\n" ;;

	     esac ;;

	 
       *)

         printf "\nYou have entered an invalid file prefix" ;;

esac ;




