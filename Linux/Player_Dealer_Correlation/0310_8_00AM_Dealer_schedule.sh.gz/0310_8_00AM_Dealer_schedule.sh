#!/bin/bash

awk -F'\t' '{print $1, $3}' 0310_Dealer_schedule | grep -e '08:00:00 AM' >> Dealers_working_during_losses

 
